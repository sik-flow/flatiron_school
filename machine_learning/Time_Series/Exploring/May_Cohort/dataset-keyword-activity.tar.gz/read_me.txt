Read me is available at :
http://ama.liglab.fr/resourcestools/datasets/predict-keywords-activities-in-a-online-social-media/
